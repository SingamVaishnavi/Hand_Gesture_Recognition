import os
import cv2
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score

data = []
labels = []

gestures = {
    "thumbs_up": 0,
    "palm": 1,
    "peace": 2,
    "fist": 3
}

for gesture, label in gestures.items():

    folder = os.path.join("gestures", gesture)

    for file in os.listdir(folder):

        path = os.path.join(folder, file)

        img = cv2.imread(path)

        if img is not None:

            img = cv2.resize(img, (64,64))

            data.append(img.flatten())
            labels.append(label)

X = np.array(data)
y = np.array(labels)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

model = SVC(kernel='linear')

model.fit(X_train, y_train)

y_pred = model.predict(X_test)

print("Accuracy:", accuracy_score(y_test, y_pred))