# Hand Gesture Recognition using SVM

## Objective
Recognize different hand gestures using Machine Learning.

## Gestures
- Thumbs Up
- Palm
- Peace
- Fist

## Technologies Used
- Python
- OpenCV
- NumPy
- Scikit-Learn

## Algorithm
Support Vector Machine (SVM)

## Output
Predicts hand gesture categories and displays accuracy.